from logisticsapp import views
from django.urls import path
urlpatterns = [
    path("register/", views.register, name="register"),  # <-- added
    path("login/", views.login_request, name="login"),
    path("logout/", views.logout_request, name="logout"),
    path('home/', views.routeLogistics_list, name='home'),
    path('<int:pk>/', views.routeLogistics_detail, name='routeLogistics_detail'),
    path('create/', views.routeLogistics_create, name='routeLogistics_create'),
    path('<int:pk>/update/', views.routeLogistics_update, name='routeLogistics_update'),
    path('<int:pk>/delete/', views.routeLogistics_delete, name='routeLogistics_delete'),
    ]